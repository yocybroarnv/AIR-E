"""
Feature Engineering Module for AIR-E
Implements specific formulas from the methodology
"""
import pandas as pd
import numpy as np
from utils.geography import BORDER_DISTRICTS

def calculate_update_churn_index(metrics_df):
    """
    Update Churn Index
    Formula: total demographic updates / (total enrollments + 1)
    Purpose: Detects identity stabilisation behaviour after enrolment
    """
    metrics_df = metrics_df.copy()
    
    metrics_df['update_churn_index'] = (
        metrics_df['demographic_updates'] / 
        (metrics_df['total_enrollments'] + 1)
    )
    
    return metrics_df

def calculate_document_risk_score(metrics_df):
    """
    Document Risk Score
    Formula: total demographic updates / (biometric updates + 1)
    Purpose: Indicates reliance on non-biometric document-based changes
    """
    metrics_df = metrics_df.copy()
    
    metrics_df['document_risk_score'] = (
        metrics_df['demographic_updates'] / 
        (metrics_df['biometric_updates'] + 1)
    )
    
    return metrics_df

def calculate_border_enrolment_spike(metrics_df, window=3):
    """
    Border Enrolment Spike
    Logic: Border district AND enrollments > 3x rolling average
    Purpose: Proxy indicator for illegal immigration driven enrolment surges
    """
    metrics_df = metrics_df.copy()
    
    # Calculate rolling average for each district
    for district in metrics_df['district'].unique():
        district_mask = metrics_df['district'] == district
        district_data = metrics_df[district_mask].sort_values('month')
        
        # Calculate rolling average
        rolling_avg = district_data['total_enrollments'].rolling(
            window=window, min_periods=1
        ).mean()
        
        metrics_df.loc[district_mask, 'rolling_avg_enrollments'] = rolling_avg.values
    
    # Detect border spike
    metrics_df['border_enrolment_spike'] = (
        (metrics_df['is_border_district'] == True) &
        (metrics_df['total_enrollments'] > 3 * metrics_df['rolling_avg_enrollments'])
    ).astype(int)
    
    return metrics_df

def calculate_forecast_deviation_score(metrics_df, window=3):
    """
    Forecast Deviation Score
    Logic: Difference between predicted and actual enrolment behaviour
    Purpose: Early signal of emerging fraud clusters
    """
    metrics_df = metrics_df.copy()
    
    # Simple forecast using moving average
    for district in metrics_df['district'].unique():
        district_mask = metrics_df['district'] == district
        district_data = metrics_df[district_mask].sort_values('month')
        
        # Forecast = previous period moving average
        rolling_avg = district_data['total_enrollments'].rolling(
            window=window, min_periods=1
        ).mean()
        
        # Shift by 1 to get previous period's average
        forecast = rolling_avg.shift(1).fillna(rolling_avg)
        
        # Deviation = actual - forecast
        deviation = district_data['total_enrollments'] - forecast
        
        # Normalize deviation
        std_dev = district_data['total_enrollments'].std()
        if std_dev > 0:
            z_score = deviation / std_dev
        else:
            z_score = pd.Series([0] * len(district_data))
        
        metrics_df.loc[district_mask, 'forecast_deviation'] = deviation.values
        metrics_df.loc[district_mask, 'forecast_deviation_zscore'] = z_score.values
    
    # Forecast deviation score (0-1 scale)
    max_dev = abs(metrics_df['forecast_deviation_zscore']).max()
    if max_dev > 0:
        metrics_df['forecast_deviation_score'] = (
            abs(metrics_df['forecast_deviation_zscore']) / max_dev
        ).clip(0, 1)
    else:
        metrics_df['forecast_deviation_score'] = 0
    
    return metrics_df

def calculate_operator_velocity_proxy(metrics_df):
    """
    Operator Velocity Proxy (simplified)
    Logic: Unusually high update volume concentrated in low population zones
    Note: Since we don't have operator-level granularity in aggregate data,
    we use update-to-enrollment ratio as a proxy
    """
    metrics_df = metrics_df.copy()
    
    # Calculate update velocity (updates per enrollment)
    metrics_df['update_velocity'] = (
        metrics_df['demographic_updates'] / 
        (metrics_df['total_enrollments'] + 1)
    )
    
    # Flag unusually high velocity
    velocity_threshold = metrics_df['update_velocity'].quantile(0.75)
    metrics_df['operator_velocity_anomaly'] = (
        metrics_df['update_velocity'] > velocity_threshold
    ).astype(int)
    
    return metrics_df

def calculate_lifecycle_inconsistency(metrics_df):
    """
    Lifecycle Inconsistency
    Compares enrollment, demographic updates, and biometric updates
    High demographic updates relative to biometric = suspicious pattern
    """
    metrics_df = metrics_df.copy()
    
    # Calculate ratios
    total_updates = metrics_df['demographic_updates'] + metrics_df['biometric_updates']
    
    metrics_df['demo_update_ratio'] = (
        metrics_df['demographic_updates'] / (total_updates + 1)
    )
    
    metrics_df['bio_update_ratio'] = (
        metrics_df['biometric_updates'] / (total_updates + 1)
    )
    
    # Lifecycle inconsistency: high demo, low bio
    metrics_df['lifecycle_inconsistency'] = (
        (metrics_df['demo_update_ratio'] > 0.7) &
        (metrics_df['bio_update_ratio'] < 0.3)
    ).astype(int)
    
    return metrics_df

def calculate_adult_enrolment_spike(metrics_df, window=3):
    """
    Adult Enrolment Spike
    Border districts showing adult enrolment spikes far exceeding population growth
    """
    metrics_df = metrics_df.copy()
    
    # Calculate rolling average for adult enrollments
    for district in metrics_df['district'].unique():
        district_mask = metrics_df['district'] == district
        district_data = metrics_df[district_mask].sort_values('month')
        
        rolling_avg_adult = district_data['age_18_greater'].rolling(
            window=window, min_periods=1
        ).mean()
        
        metrics_df.loc[district_mask, 'rolling_avg_adult_enrollments'] = rolling_avg_adult.values
    
    # Detect spike: > 2x rolling average in border districts
    metrics_df['adult_enrolment_spike'] = (
        (metrics_df['is_border_district'] == True) &
        (metrics_df['age_18_greater'] > 2 * metrics_df['rolling_avg_adult_enrollments'])
    ).astype(int)
    
    return metrics_df

def apply_all_feature_engineering(metrics_df):
    """Apply all feature engineering steps"""
    df = metrics_df.copy()
    
    # Calculate all features
    df = calculate_update_churn_index(df)
    df = calculate_document_risk_score(df)
    df = calculate_border_enrolment_spike(df)
    df = calculate_forecast_deviation_score(df)
    df = calculate_operator_velocity_proxy(df)
    df = calculate_lifecycle_inconsistency(df)
    df = calculate_adult_enrolment_spike(df)
    
    return df
