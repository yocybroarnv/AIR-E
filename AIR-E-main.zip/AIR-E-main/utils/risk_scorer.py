"""
Risk Scoring Module
Combines anomaly detection and forecasting for final risk scores
"""
import pandas as pd
import numpy as np

class RiskScorer:
    """Combines multiple risk signals into a unified risk score"""
    
    def __init__(self, anomaly_weight=0.4, forecast_weight=0.4, trend_weight=0.2):
        self.anomaly_weight = anomaly_weight
        self.forecast_weight = forecast_weight
        self.trend_weight = trend_weight
    
    def calculate_composite_score(self, df):
        """Calculate composite fraud risk probability score (0-1)"""
        df_scored = df.copy()
        
        # Normalize individual scores to 0-1 range
        scores = {}
        
        # Anomaly score
        if 'anomaly_score' in df_scored.columns:
            scores['anomaly'] = self._normalize(df_scored['anomaly_score'].fillna(0))
        
        # Forecast score
        if 'forecast_risk_score' in df_scored.columns:
            scores['forecast'] = self._normalize(df_scored['forecast_risk_score'].fillna(0))
        
        # Trend deviation score
        if 'trend_deviation' in df_scored.columns:
            trend_abs = np.abs(df_scored['trend_deviation'].fillna(0))
            scores['trend'] = self._normalize(trend_abs)
        
        # Calculate weighted composite score
        composite = np.zeros(len(df_scored))
        total_weight = 0
        
        if 'anomaly' in scores:
            composite += scores['anomaly'] * self.anomaly_weight
            total_weight += self.anomaly_weight
        
        if 'forecast' in scores:
            composite += scores['forecast'] * self.forecast_weight
            total_weight += self.forecast_weight
        
        if 'trend' in scores:
            composite += scores['trend'] * self.trend_weight
            total_weight += self.trend_weight
        
        # Normalize by total weight
        if total_weight > 0:
            composite = composite / total_weight
        
        # Ensure 0-1 range
        composite = np.clip(composite, 0, 1)
        
        df_scored['fraud_risk_score'] = composite
        
        return df_scored
    
    def _normalize(self, series):
        """Normalize series to 0-1 range"""
        if series.min() == series.max():
            return pd.Series([0.5] * len(series))
        return (series - series.min()) / (series.max() - series.min())
    
    def apply_risk_categories(self, df, thresholds=None):
        """Apply risk categories based on score"""
        if thresholds is None:
            thresholds = {
                'p50': 0.3,
                'p75': 0.5,
                'p90': 0.7,
                'p95': 0.85
            }
        
        def categorize(score):
            if score >= thresholds.get('p95', 0.85):
                return 'Critical'
            elif score >= thresholds.get('p90', 0.7):
                return 'High'
            elif score >= thresholds.get('p75', 0.5):
                return 'Medium'
            elif score >= thresholds.get('p50', 0.3):
                return 'Low'
            else:
                return 'Very Low'
        
        df['risk_category'] = df['fraud_risk_score'].apply(categorize)
        
        # Risk priority for sorting
        priority_map = {
            'Critical': 5,
            'High': 4,
            'Medium': 3,
            'Low': 2,
            'Very Low': 1
        }
        df['risk_priority'] = df['risk_category'].map(priority_map)
        
        return df
