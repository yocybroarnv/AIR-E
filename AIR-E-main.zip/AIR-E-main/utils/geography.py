"""
Geographic utilities for AIR-E
Handles border districts, state mapping, and geographic risk features
"""
import pandas as pd

# Border districts near Nepal and Bangladesh (based on actual geography)
BORDER_DISTRICTS_NEPAL = [
    'Araria', 'Kishanganj', 'Purnia', 'Madhubani', 'Supaul', 
    'Sitamarhi', 'Sheohar', 'Muzaffarpur', 'East Champaran', 'West Champaran'
]

BORDER_DISTRICTS_BANGLADESH = [
    'Cooch Behar', 'Jalpaiguri', 'Alipurduar', 'Malda', 'Murshidabad',
    'Nadia', 'North 24 Parganas', 'South 24 Parganas'
]

# Combine all border districts
BORDER_DISTRICTS = set(BORDER_DISTRICTS_NEPAL + BORDER_DISTRICTS_BANGLADESH)

# State to districts mapping (sample for demo)
STATE_DISTRICT_MAP = {
    'Bihar': ['Araria', 'Kishanganj', 'Purnia', 'Patna', 'Muzaffarpur', 'Madhubani'],
    'West Bengal': ['Kolkata', 'Cooch Behar', 'Jalpaiguri', 'Malda', 'Murshidabad', 'Nadia'],
    'Maharashtra': ['Mumbai', 'Pune', 'Nagpur', 'Thane', 'Nashik'],
    'Delhi': ['Delhi'],
    'Karnataka': ['Bangalore'],
    'Tamil Nadu': ['Chennai'],
    'Telangana': ['Hyderabad'],
    'Gujarat': ['Ahmedabad', 'Surat', 'Rajkot', 'Vadodara'],
    'Rajasthan': ['Jaipur'],
    'Uttar Pradesh': ['Lucknow', 'Kanpur', 'Agra', 'Varanasi', 'Meerut', 'Ghaziabad', 'Noida', 'Faridabad'],
    'Jammu and Kashmir': ['Srinagar'],
    'Punjab': ['Amritsar', 'Ludhiana'],
    'Madhya Pradesh': ['Indore', 'Bhopal'],
    'Odisha': ['Visakhapatnam']
}

def is_border_district(district_name):
    """Check if a district is a border district"""
    return district_name in BORDER_DISTRICTS

def get_state_for_district(district_name):
    """Get state for a given district"""
    for state, districts in STATE_DISTRICT_MAP.items():
        if district_name in districts:
            return state
    return 'Unknown'

def add_geographic_features(df):
    """Add geographic risk features to dataframe"""
    df = df.copy()
    
    # Add border flag
    df['is_border_district'] = df['district'].apply(is_border_district)
    
    # Add state if not present
    if 'state' not in df.columns:
        df['state'] = df['district'].apply(get_state_for_district)
    
    return df

def get_district_coordinates():
    """Get approximate coordinates for districts (for mapping)"""
    # Approximate coordinates for major districts
    coordinates = {
        # Border districts - Bihar
        'Araria': (26.15, 87.52),
        'Kishanganj': (26.10, 87.95),
        'Purnia': (25.78, 87.47),
        'Madhubani': (26.37, 86.08),
        'Patna': (25.59, 85.14),
        'Muzaffarpur': (26.12, 85.39),
        
        # Border districts - West Bengal
        'Cooch Behar': (26.32, 89.45),
        'Jalpaiguri': (26.52, 88.73),
        'Malda': (25.01, 88.15),
        'Murshidabad': (24.18, 88.27),
        'Kolkata': (22.57, 88.36),
        'Nadia': (23.40, 88.50),
        
        # Major cities
        'Mumbai': (19.08, 72.88),
        'Delhi': (28.61, 77.23),
        'Bangalore': (12.97, 77.59),
        'Hyderabad': (17.39, 78.49),
        'Chennai': (13.08, 80.27),
        'Pune': (18.52, 73.86),
        'Ahmedabad': (23.03, 72.59),
        'Jaipur': (26.91, 75.79),
        'Surat': (21.17, 72.83),
        'Lucknow': (26.85, 80.95),
        'Kanpur': (26.45, 80.33),
        'Nagpur': (21.15, 79.08),
        'Indore': (22.72, 75.86),
        'Thane': (19.19, 72.97),
        'Bhopal': (23.26, 77.41),
        'Visakhapatnam': (17.69, 83.22),
        'Vadodara': (22.31, 73.18),
        'Ghaziabad': (28.67, 77.42),
        'Ludhiana': (30.90, 75.85),
        'Agra': (27.18, 78.01),
        'Nashik': (19.99, 73.79),
        'Faridabad': (28.41, 77.32),
        'Meerut': (28.98, 77.71),
        'Rajkot': (22.30, 70.80),
        'Varanasi': (25.32, 82.97),
        'Srinagar': (34.08, 74.82),
        'Amritsar': (31.63, 74.87),
        'Noida': (28.54, 77.39),
    }
    
    return coordinates
