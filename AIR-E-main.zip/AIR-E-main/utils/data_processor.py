"""
Data Processing Utilities
"""
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

def calculate_trend_deviations(df, window=3):
    """Calculate rolling window trend deviations"""
    df_processed = df.copy()
    
    for district in df_processed['district'].unique():
        district_mask = df_processed['district'] == district
        district_data = df_processed[district_mask].sort_values('month')
        
        # Calculate rolling mean and std
        rolling_mean = district_data['total_enrollments'].rolling(window=window, min_periods=1).mean()
        rolling_std = district_data['total_enrollments'].rolling(window=window, min_periods=1).std().fillna(0)
        
        # Calculate z-score deviation
        current_values = district_data['total_enrollments'].values
        mean_values = rolling_mean.values
        std_values = rolling_std.values
        
        z_scores = np.where(std_values > 0, 
                           (current_values - mean_values) / std_values,
                           0)
        
        df_processed.loc[district_mask, 'trend_deviation'] = z_scores
        df_processed.loc[district_mask, 'trend_anomaly'] = (np.abs(z_scores) > 2).astype(int)
    
    return df_processed

def aggregate_district_metrics(df, update_df=None):
    """Aggregate metrics at district-month level"""
    # This will use the metrics from data_generator if needed
    # For now, return the input df if it's already aggregated
    return df

def calculate_risk_thresholds(df, column='fraud_risk_score', percentiles=[50, 75, 90, 95]):
    """Calculate risk thresholds based on percentiles"""
    thresholds = {}
    for p in percentiles:
        thresholds[f'p{p}'] = df[column].quantile(p / 100)
    return thresholds

def categorize_risk_level(score, thresholds):
    """Categorize risk score into levels"""
    if score >= thresholds.get('p95', 0.9):
        return 'Critical'
    elif score >= thresholds.get('p90', 0.75):
        return 'High'
    elif score >= thresholds.get('p75', 0.5):
        return 'Medium'
    elif score >= thresholds.get('p50', 0.25):
        return 'Low'
    else:
        return 'Very Low'
