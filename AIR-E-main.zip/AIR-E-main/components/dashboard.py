"""
Dashboard Component Functions
"""
import streamlit as st
import pandas as pd
from components.visualizations import *

def render_metrics_cards(df):
    """Render key metrics cards"""
    latest_month = df['year_month'].max()
    latest_df = df[df['year_month'] == latest_month]
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        total_districts = len(latest_df)
        st.metric("Active Districts", total_districts)
    
    with col2:
        avg_risk = latest_df['fraud_risk_score'].mean()
        st.metric("Average Risk Score", f"{avg_risk:.3f}")
    
    with col3:
        high_risk = len(latest_df[latest_df['risk_category'].isin(['Critical', 'High'])])
        st.metric("High Risk Districts", high_risk, delta=f"{high_risk/total_districts*100:.1f}%")
    
    with col4:
        total_enrollments = latest_df['total_enrollments'].sum()
        st.metric("Total Enrollments", f"{total_enrollments:,}")

def render_risk_table(df, max_rows=100):
    """Render sortable risk table"""
    display_cols = [
        'district', 'year_month', 'fraud_risk_score', 'risk_category',
        'total_enrollments', 'unique_operators', 'update_count'
    ]
    
    available_cols = [col for col in display_cols if col in df.columns]
    display_df = df[available_cols].copy()
    
    # Format columns
    if 'fraud_risk_score' in display_df.columns:
        display_df['fraud_risk_score'] = display_df['fraud_risk_score'].apply(lambda x: f"{x:.3f}")
    
    # Sort by risk score
    display_df = display_df.sort_values(
        by='fraud_risk_score' if 'fraud_risk_score' in display_df.columns else 'district',
        ascending=False
    ).head(max_rows)
    
    st.dataframe(display_df, use_container_width=True, hide_index=True)

def render_filter_sidebar(df):
    """Render filter sidebar"""
    st.sidebar.header("Filters")
    
    # Month filter
    available_months = sorted(df['year_month'].unique(), reverse=True)
    selected_months = st.sidebar.multiselect(
        "Select Months",
        options=available_months,
        default=available_months[:3]
    )
    
    # District filter
    available_districts = sorted(df['district'].unique())
    selected_districts = st.sidebar.multiselect(
        "Select Districts",
        options=available_districts,
        default=[]
    )
    
    # Risk category filter
    available_categories = sorted(df['risk_category'].unique())
    selected_categories = st.sidebar.multiselect(
        "Risk Categories",
        options=available_categories,
        default=available_categories
    )
    
    # Apply filters
    filtered_df = df.copy()
    
    if selected_months:
        filtered_df = filtered_df[filtered_df['year_month'].isin(selected_months)]
    
    if selected_districts:
        filtered_df = filtered_df[filtered_df['district'].isin(selected_districts)]
    
    if selected_categories:
        filtered_df = filtered_df[filtered_df['risk_category'].isin(selected_categories)]
    
    # Risk score threshold
    min_risk = float(df['fraud_risk_score'].min())
    max_risk = float(df['fraud_risk_score'].max())
    risk_range = st.sidebar.slider(
        "Risk Score Range",
        min_value=min_risk,
        max_value=max_risk,
        value=(min_risk, max_risk),
        step=0.01
    )
    
    filtered_df = filtered_df[
        (filtered_df['fraud_risk_score'] >= risk_range[0]) &
        (filtered_df['fraud_risk_score'] <= risk_range[1])
    ]
    
    return filtered_df

def render_analysis_insights(df):
    """Render analysis insights"""
    latest_month = df['year_month'].max()
    latest_df = df[df['year_month'] == latest_month]
    
    st.subheader("Key Insights")
    
    # Top risk districts
    top_risk = latest_df.nlargest(5, 'fraud_risk_score')[['district', 'fraud_risk_score', 'risk_category']]
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.write("**Top 5 Risk Districts**")
        for idx, row in top_risk.iterrows():
            st.write(f"• {row['district']}: {row['fraud_risk_score']:.3f} ({row['risk_category']})")
    
    with col2:
        st.write("**Risk Distribution**")
        category_counts = latest_df['risk_category'].value_counts()
        for category, count in category_counts.items():
            percentage = (count / len(latest_df)) * 100
            st.write(f"• {category}: {count} districts ({percentage:.1f}%)")
