"""
Visualization Components for AIR-E Dashboard
"""
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots

def plot_risk_heatmap(df):
    """Create district-month risk heatmap"""
    pivot_df = df.pivot_table(
        index='district',
        columns='year_month',
        values='fraud_risk_score',
        aggfunc='mean'
    )
    
    fig = px.imshow(
        pivot_df,
        labels=dict(x="Month", y="District", color="Risk Score"),
        color_continuous_scale='RdYlGn_r',
        aspect="auto",
        title="District-Level Fraud Risk Heatmap"
    )
    
    fig.update_layout(
        height=max(600, len(pivot_df) * 25),
        xaxis_title="Month",
        yaxis_title="District"
    )
    
    return fig

def plot_risk_trends(df, districts=None):
    """Plot risk trends over time for selected districts"""
    if districts is None:
        districts = df.nlargest(5, 'fraud_risk_score')['district'].unique()
    
    plot_df = df[df['district'].isin(districts)].copy()
    
    fig = px.line(
        plot_df,
        x='month',
        y='fraud_risk_score',
        color='district',
        title='Fraud Risk Score Trends by District',
        labels={'fraud_risk_score': 'Fraud Risk Score', 'month': 'Month'}
    )
    
    fig.update_layout(
        height=500,
        hovermode='x unified'
    )
    
    return fig

def plot_district_comparison(df, metric='fraud_risk_score', top_n=10):
    """Compare districts by risk metric"""
    latest_month = df['year_month'].max()
    latest_df = df[df['year_month'] == latest_month].nlargest(top_n, metric)
    
    fig = px.bar(
        latest_df,
        x=metric,
        y='district',
        orientation='h',
        title=f'Top {top_n} Districts by {metric.replace("_", " ").title()} ({latest_month})',
        labels={metric: metric.replace("_", " ").title(), 'district': 'District'},
        color=metric,
        color_continuous_scale='RdYlGn_r'
    )
    
    fig.update_layout(
        height=max(400, top_n * 40),
        yaxis={'categoryorder': 'total ascending'}
    )
    
    return fig

def plot_risk_distribution(df):
    """Plot distribution of risk scores"""
    fig = px.histogram(
        df,
        x='fraud_risk_score',
        nbins=50,
        title='Distribution of Fraud Risk Scores',
        labels={'fraud_risk_score': 'Fraud Risk Score', 'count': 'Frequency'},
        color_discrete_sequence=['#1f77b4']
    )
    
    fig.update_layout(
        height=400,
        showlegend=False
    )
    
    return fig

def plot_risk_categories(df):
    """Plot risk category breakdown"""
    category_counts = df['risk_category'].value_counts()
    
    colors = {
        'Critical': '#d32f2f',
        'High': '#f57c00',
        'Medium': '#fbc02d',
        'Low': '#689f38',
        'Very Low': '#388e3c'
    }
    
    fig = px.pie(
        values=category_counts.values,
        names=category_counts.index,
        title='Risk Category Distribution',
        color=category_counts.index,
        color_discrete_map=colors
    )
    
    fig.update_layout(height=400)
    
    return fig

def plot_enrollment_vs_risk(df):
    """Scatter plot of enrollments vs risk score"""
    latest_month = df['year_month'].max()
    latest_df = df[df['year_month'] == latest_month]
    
    fig = px.scatter(
        latest_df,
        x='total_enrollments',
        y='fraud_risk_score',
        size='unique_operators',
        color='risk_category',
        hover_data=['district'],
        title=f'Enrollment Volume vs Risk Score ({latest_month})',
        labels={
            'total_enrollments': 'Total Enrollments',
            'fraud_risk_score': 'Fraud Risk Score',
            'unique_operators': 'Operators',
            'risk_category': 'Risk Category'
        },
        color_discrete_map={
            'Critical': '#d32f2f',
            'High': '#f57c00',
            'Medium': '#fbc02d',
            'Low': '#689f38',
            'Very Low': '#388e3c'
        }
    )
    
    fig.update_layout(height=500)
    
    return fig

def plot_operator_metrics(df):
    """Plot operator-level metrics"""
    if 'operator' not in df.columns:
        return None
    
    operator_stats = df.groupby('operator').agg({
        'total_enrollments': 'sum',
        'fraud_risk_score': 'mean',
        'high_same_day_enrollments': 'sum'
    }).reset_index()
    
    fig = px.scatter(
        operator_stats.nlargest(50, 'total_enrollments'),
        x='total_enrollments',
        y='fraud_risk_score',
        size='high_same_day_enrollments',
        hover_data=['operator'],
        title='Operator Performance Metrics',
        labels={
            'total_enrollments': 'Total Enrollments',
            'fraud_risk_score': 'Avg Risk Score',
            'high_same_day_enrollments': 'Suspicious Patterns'
        }
    )
    
    fig.update_layout(height=500)
    
    return fig

def plot_temporal_patterns(df):
    """Plot temporal patterns in enrollment and risk"""
    monthly_stats = df.groupby('year_month').agg({
        'total_enrollments': 'sum',
        'fraud_risk_score': 'mean',
        'update_count': 'sum'
    }).reset_index()
    
    fig = make_subplots(
        rows=2, cols=1,
        subplot_titles=('Total Enrollments Over Time', 'Average Risk Score Over Time'),
        vertical_spacing=0.1
    )
    
    fig.add_trace(
        go.Scatter(
            x=monthly_stats['year_month'],
            y=monthly_stats['total_enrollments'],
            name='Enrollments',
            line=dict(color='#1f77b4')
        ),
        row=1, col=1
    )
    
    fig.add_trace(
        go.Scatter(
            x=monthly_stats['year_month'],
            y=monthly_stats['fraud_risk_score'],
            name='Risk Score',
            line=dict(color='#d32f2f')
        ),
        row=2, col=1
    )
    
    fig.update_xaxes(title_text="Month", row=2, col=1)
    fig.update_yaxes(title_text="Total Enrollments", row=1, col=1)
    fig.update_yaxes(title_text="Risk Score", row=2, col=1)
    
    fig.update_layout(height=600, title_text="Temporal Patterns Analysis", showlegend=False)
    
    return fig

def plot_geographic_risk_map(df):
    """Create geographic risk map with district-level risk scores"""
    from utils.geography import get_district_coordinates
    
    latest_month = df['year_month'].max()
    latest_df = df[df['year_month'] == latest_month].copy()
    
    # Get coordinates
    coords = get_district_coordinates()
    
    # Add coordinates to dataframe
    latest_df['lat'] = latest_df['district'].map(lambda x: coords.get(x, (0, 0))[0])
    latest_df['lon'] = latest_df['district'].map(lambda x: coords.get(x, (0, 0))[1])
    
    # Filter out districts without coordinates
    latest_df = latest_df[latest_df['lat'] != 0]
    
    if len(latest_df) == 0:
        return None
    
    # Create scatter plot on map
    fig = px.scatter_mapbox(
        latest_df,
        lat='lat',
        lon='lon',
        color='fraud_risk_score',
        size='total_enrollments',
        hover_name='district',
        hover_data=['state', 'risk_category', 'fraud_risk_score', 'total_enrollments'],
        color_continuous_scale='RdYlGn_r',
        size_max=30,
        zoom=4,
        center=dict(lat=23.5, lon=77.5),
        mapbox_style='open-street-map',
        title='Geographic Risk Heat Map - District Level Risk Scores'
    )
    
    fig.update_layout(height=700, margin=dict(l=0, r=0, t=50, b=0))
    
    return fig

def plot_heat_zones(df):
    """Create heat zone visualization highlighting high-risk clusters"""
    from utils.geography import get_district_coordinates
    
    latest_month = df['year_month'].max()
    latest_df = df[df['year_month'] == latest_month].copy()
    
    # Get coordinates
    coords = get_district_coordinates()
    
    # Add coordinates
    latest_df['lat'] = latest_df['district'].map(lambda x: coords.get(x, (0, 0))[0])
    latest_df['lon'] = latest_df['district'].map(lambda x: coords.get(x, (0, 0))[1])
    latest_df = latest_df[latest_df['lat'] != 0]
    
    if len(latest_df) == 0:
        return None
    
    # Create density-based heat zones
    fig = px.density_mapbox(
        latest_df,
        lat='lat',
        lon='lon',
        z='fraud_risk_score',
        radius=30,
        hover_name='district',
        hover_data=['risk_category', 'fraud_risk_score'],
        color_continuous_scale='RdYlGn_r',
        zoom=4,
        center=dict(lat=23.5, lon=77.5),
        mapbox_style='open-street-map',
        title='Risk Heat Zones - Density Visualization'
    )
    
    fig.update_layout(height=700, margin=dict(l=0, r=0, t=50, b=0))
    
    return fig

def plot_border_districts_analysis(df):
    """Analyze border districts separately"""
    latest_month = df['year_month'].max()
    latest_df = df[df['year_month'] == latest_month].copy()
    
    border_df = latest_df[latest_df['is_border_district'] == True].sort_values('fraud_risk_score', ascending=False)
    non_border_df = latest_df[latest_df['is_border_district'] == False].sort_values('fraud_risk_score', ascending=False)
    
    fig = go.Figure()
    
    # Border districts
    fig.add_trace(go.Bar(
        x=border_df['district'].head(10),
        y=border_df['fraud_risk_score'].head(10),
        name='Border Districts',
        marker_color='#d32f2f'
    ))
    
    # Non-border districts
    fig.add_trace(go.Bar(
        x=non_border_df['district'].head(10),
        y=non_border_df['fraud_risk_score'].head(10),
        name='Non-Border Districts',
        marker_color='#1976d2'
    ))
    
    fig.update_layout(
        title='Risk Comparison: Border vs Non-Border Districts',
        xaxis_title='District',
        yaxis_title='Fraud Risk Score',
        barmode='group',
        height=500
    )
    
    return fig

def plot_lifecycle_inconsistency_chart(df):
    """Compare enrollment, demographic updates, and biometric updates"""
    latest_month = df['year_month'].max()
    latest_df = df[df['year_month'] == latest_month].nlargest(15, 'fraud_risk_score')
    
    fig = go.Figure()
    
    fig.add_trace(go.Bar(
        name='Enrollments',
        x=latest_df['district'],
        y=latest_df['total_enrollments'],
        marker_color='#1f77b4'
    ))
    
    fig.add_trace(go.Bar(
        name='Demographic Updates',
        x=latest_df['district'],
        y=latest_df['demographic_updates'],
        marker_color='#ff7f0e'
    ))
    
    fig.add_trace(go.Bar(
        name='Biometric Updates',
        x=latest_df['district'],
        y=latest_df['biometric_updates'],
        marker_color='#2ca02c'
    ))
    
    fig.update_layout(
        title='Lifecycle Inconsistency Analysis - Top Risk Districts',
        xaxis_title='District',
        yaxis_title='Count',
        barmode='group',
        height=500,
        xaxis_tickangle=-45
    )
    
    return fig

def plot_document_risk_analysis(df):
    """Visualize document risk scores"""
    latest_month = df['year_month'].max()
    latest_df = df[df['year_month'] == latest_month].copy()
    
    # Scatter plot: Document Risk vs Total Risk
    fig = px.scatter(
        latest_df,
        x='document_risk_score',
        y='fraud_risk_score',
        size='total_enrollments',
        color='is_border_district',
        hover_data=['district', 'state'],
        title='Document Risk Score vs Composite Risk Score',
        labels={
            'document_risk_score': 'Document Risk Score',
            'fraud_risk_score': 'Composite Risk Score',
            'is_border_district': 'Border District'
        },
        color_discrete_map={True: '#d32f2f', False: '#1976d2'}
    )
    
    fig.update_layout(height=500)
    
    return fig

def plot_border_spike_analysis(df):
    """Visualize border enrollment spikes over time"""
    border_df = df[df['is_border_district'] == True].copy()
    
    if len(border_df) == 0:
        return None
    
    # Get top border districts by risk
    top_border = border_df.groupby('district')['fraud_risk_score'].max().nlargest(5).index
    plot_df = border_df[border_df['district'].isin(top_border)]
    
    fig = px.line(
        plot_df,
        x='month',
        y='total_enrollments',
        color='district',
        title='Border District Enrollment Trends (Top 5 by Risk)',
        labels={'total_enrollments': 'Total Enrollments', 'month': 'Month'}
    )
    
    fig.update_layout(height=500, hovermode='x unified')
    
    return fig

def create_risk_map_data(df):
    """Prepare data for geographic risk mapping"""
    from utils.geography import get_district_coordinates
    
    latest_month = df['year_month'].max()
    latest_df = df[df['year_month'] == latest_month].copy()
    
    coords = get_district_coordinates()
    
    latest_df['lat'] = latest_df['district'].map(lambda x: coords.get(x, (0, 0))[0])
    latest_df['lon'] = latest_df['district'].map(lambda x: coords.get(x, (0, 0))[1])
    
    return latest_df
