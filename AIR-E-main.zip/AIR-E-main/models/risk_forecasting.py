"""
Risk Forecasting Module using XGBoost
"""
import numpy as np
import pandas as pd
import xgboost as xgb
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
import warnings
warnings.filterwarnings('ignore')

class RiskForecaster:
    """XGBoost-based fraud risk forecasting"""
    
    def __init__(self, random_state=42):
        self.model = xgb.XGBClassifier(
            random_state=random_state,
            n_estimators=100,
            max_depth=6,
            learning_rate=0.1,
            subsample=0.8,
            colsample_bytree=0.8,
            eval_metric='logloss'
        )
        self.scaler = StandardScaler()
        self.feature_columns = None
        self.is_trained = False
        
    def prepare_features(self, df, include_target=True):
        """Prepare features for risk forecasting"""
        # Feature engineering
        features_df = df.copy()
        
        # Calculate rolling statistics
        for district in features_df['district'].unique():
            district_mask = features_df['district'] == district
            district_data = features_df[district_mask].sort_values('month')
            
            # Rolling averages
            features_df.loc[district_mask, 'enrollments_ma3'] = \
                district_data['total_enrollments'].rolling(window=3, min_periods=1).mean().values
            features_df.loc[district_mask, 'enrollments_ma6'] = \
                district_data['total_enrollments'].rolling(window=6, min_periods=1).mean().values
            
            # Rate of change
            features_df.loc[district_mask, 'enrollments_roc'] = \
                district_data['total_enrollments'].pct_change().fillna(0).values
            
        # Selected features
        base_features = [
            'total_enrollments',
            'unique_operators',
            'high_same_day_enrollments',
            'avg_cluster_size',
            'operator_avg_daily_count',
            'update_count',
            'avg_updates_per_enrollment',
            'enrollment_rate_change',
            'operator_variance',
            'enrollments_ma3',
            'enrollments_ma6',
            'enrollments_roc'
        ]
        
        # Use available features
        available_features = [f for f in base_features if f in features_df.columns]
        
        if include_target and 'risk_label' in features_df.columns:
            X = features_df[available_features].fillna(0)
            y = features_df['risk_label']
            self.feature_columns = available_features
            return X, y
        else:
            X = features_df[available_features].fillna(0)
            self.feature_columns = available_features
            return X
    
    def create_risk_labels(self, df, threshold_percentile=75):
        """Create risk labels based on anomaly scores"""
        df_labeled = df.copy()
        
        # Create risk labels based on multiple indicators
        # High risk = top percentile of suspicious indicators
        risk_indicators = [
            'total_enrollments',
            'high_same_day_enrollments',
            'avg_updates_per_enrollment',
            'enrollment_rate_change'
        ]
        
        risk_score = 0
        for indicator in risk_indicators:
            if indicator in df_labeled.columns:
                percentile_value = df_labeled[indicator].quantile(threshold_percentile / 100)
                risk_score += (df_labeled[indicator] > percentile_value).astype(int)
        
        # Label as high risk if multiple indicators are high
        df_labeled['risk_label'] = (risk_score >= 2).astype(int)
        
        return df_labeled
    
    def fit(self, df):
        """Train the risk forecasting model"""
        # Create risk labels
        df_labeled = self.create_risk_labels(df)
        
        # Prepare features
        X, y = self.prepare_features(df_labeled, include_target=True)
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y
        )
        
        # Scale features
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_test_scaled = self.scaler.transform(X_test)
        
        # Train model
        self.model.fit(
            X_train_scaled, y_train,
            eval_set=[(X_test_scaled, y_test)],
            verbose=False
        )
        
        self.is_trained = True
        return self
    
    def predict_proba(self, df):
        """Predict fraud risk probability (0-1)"""
        if not self.is_trained:
            # If not trained, use simple heuristic
            return self._heuristic_risk_score(df)
        
        X = self.prepare_features(df, include_target=False)
        X_scaled = self.scaler.transform(X)
        
        # Get probability of high risk class
        probabilities = self.model.predict_proba(X_scaled)
        risk_scores = probabilities[:, 1] if probabilities.shape[1] > 1 else probabilities[:, 0]
        
        return risk_scores
    
    def _heuristic_risk_score(self, df):
        """Fallback heuristic risk scoring"""
        risk_score = np.zeros(len(df))
        
        # Normalize features and create composite score
        features = ['total_enrollments', 'high_same_day_enrollments', 
                   'avg_updates_per_enrollment', 'enrollment_rate_change']
        
        for feature in features:
            if feature in df.columns:
                feature_values = df[feature].fillna(0)
                normalized = (feature_values - feature_values.min()) / \
                            (feature_values.max() - feature_values.min() + 1e-8)
                risk_score += normalized
        
        # Normalize to 0-1
        risk_score = risk_score / len(features)
        return risk_score
    
    def get_feature_importance(self):
        """Get feature importance from trained model"""
        if self.is_trained and self.feature_columns:
            importance = self.model.feature_importances_
            return dict(zip(self.feature_columns, importance))
        return None
