"""
Anomaly Detection Module using Isolation Forest
"""
import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
import warnings
warnings.filterwarnings('ignore')

class AnomalyDetector:
    """Isolation Forest based anomaly detection for district-level patterns"""
    
    def __init__(self, contamination=0.1, random_state=42):
        self.model = IsolationForest(
            contamination=contamination,
            random_state=random_state,
            n_estimators=100
        )
        self.scaler = StandardScaler()
        self.feature_columns = None
        
    def prepare_features(self, df):
        """Prepare features for anomaly detection"""
        features = [
            'total_enrollments',
            'age_18_greater',
            'demographic_updates',
            'biometric_updates',
            'update_churn_index',
            'document_risk_score',
            'forecast_deviation_score',
            'enrollment_rate_change',
            'border_enrolment_spike',
            'adult_enrolment_spike',
            'lifecycle_inconsistency'
        ]
        
        # Use available features
        available_features = [f for f in features if f in df.columns]
        feature_df = df[available_features].copy()
        
        # Fill NaN values
        feature_df = feature_df.fillna(feature_df.median())
        
        self.feature_columns = available_features
        return feature_df
    
    def fit(self, df):
        """Train the anomaly detection model"""
        feature_df = self.prepare_features(df)
        
        # Scale features
        feature_scaled = self.scaler.fit_transform(feature_df)
        
        # Train model
        self.model.fit(feature_scaled)
        
        return self
    
    def predict(self, df):
        """Predict anomalies"""
        feature_df = self.prepare_features(df)
        
        # Scale features
        feature_scaled = self.scaler.transform(feature_df)
        
        # Predict (-1 for anomaly, 1 for normal)
        predictions = self.model.predict(feature_scaled)
        anomaly_scores = self.model.score_samples(feature_scaled)
        
        # Convert to 0-1 scale (lower score = more anomalous)
        normalized_scores = (anomaly_scores - anomaly_scores.min()) / (anomaly_scores.max() - anomaly_scores.min() + 1e-8)
        risk_scores = 1 - normalized_scores  # Invert so higher = more risky
        
        results = df.copy()
        results['is_anomaly'] = (predictions == -1).astype(int)
        results['anomaly_score'] = risk_scores
        
        return results
    
    def get_feature_importance(self):
        """Get feature importance (based on model attributes)"""
        if hasattr(self.model, 'feature_importances_'):
            return dict(zip(self.feature_columns, self.model.feature_importances_))
        return None
